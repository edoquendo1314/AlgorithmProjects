package huffmancompression;
import java.io.*;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		huffmanBinaryTree object = new huffmanBinaryTree();
		treeNode root = new treeNode();
		treeNode listHead = new treeNode();
		
		try 
		{
			Scanner inFile = new Scanner(new FileReader(args[0]));
			FileWriter outFile1 = new FileWriter(args[1]);//for your debugging outputs
			FileWriter outFile2 = new FileWriter(args[2]);//contains pre-order traversal
			FileWriter outFile3 = new FileWriter(args[3]);//contains in-order traversal
			FileWriter outFile4 = new FileWriter(args[4]);
			
			object.constructHuffmanLList(inFile, outFile1);
			object.constructHuffmanBinTree(listHead, outFile1);
			object.preOrderTraversal(root, outFile2);
			object.postOrderTraversal(root, outFile3);
			object.inOrderTraversal(root, outFile4);
			
			inFile.close();
			outFile1.close();
			outFile2.close();
			outFile3.close();
			outFile4.close();
			
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
		
	}

}
