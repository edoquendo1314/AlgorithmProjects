package huffmancompression;
import java.io.*;

public class linkedList extends huffmanBinaryTree{
	//listHead -->("dummy", 0, next's chStr_1) --> (chStr_1, prob_1, next's chStr_2)...
	public treeNode listHead;

	//create constructor to handle the data
	linkedList(){
		listHead = new treeNode("dummy", 0);
		listHead.next = null; 
	}
	
	
	public treeNode findSpot(treeNode listHead, treeNode newNode) 
	{
		treeNode spot = listHead;
		if(spot.next == null)
		{
			return spot;
		}
		while(spot.next != null && newNode.prob >= spot.prob)
		{
			spot = spot.next; 
		}
		
		return spot; 
	}
	//linkedList use insertion sort
	public void insertOneNode(treeNode spot, treeNode newNode) 
	{
		if(spot.chStr == "dummy" && spot.next == null)
		{
			spot.next = newNode;
			newNode.next = null;
		}
		else
		{
			treeNode temp = spot.next;
			spot = newNode;
			newNode.next = temp; 
		}
	}
	
	public void printList(treeNode listHead, FileWriter outFile) 
	{
		try 
		{
			while(listHead.next != null)
			{	
				
					StringBuilder s = new StringBuilder();
					s.append(listHead.chStr + "," + listHead.prob + "," + listHead.next 
							+ "\n");
					outFile.write(s.toString());
				
				listHead = listHead.next; 
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
}
