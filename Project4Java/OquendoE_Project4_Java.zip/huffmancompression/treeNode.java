package huffmancompression;
import java.io.*;

public class treeNode extends huffmanBinaryTree {
	public String chStr = "";
	public String code = "";
	public int prob = 0;
	public treeNode next, left, right;
	
	//Constructor that
	//creates a node these are the specs it receives
	treeNode()
	{
		this.chStr = " ";
		this.code = " ";
		this.prob = 0;
		this.next = null;
		this.left = null;
		this.right = null;
	}
	
	treeNode(String chStr, int prob)
	{
		this.chStr = chStr;
		this.prob = prob;
	}
	//given a node, T, print T's chStr, T's prob, T's next chStr, T's left's chStr
	//T's right chStr
	//print one treeNode per text line
	public void printNode(treeNode root, FileWriter outFile)
	{
		if(root.isLeaf(root)) 
		{
			try 
			{
				StringBuilder s = new StringBuilder();
				s.append(root.chStr + "," + root.prob + "\n");
				outFile.write(s.toString());
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
		else
		{
			try 
			{
				StringBuilder s = new StringBuilder();
				s.append(root.chStr + "," + root.prob + "," 
						+ "," + root.left.chStr + "," + root.right.chStr + "\n");
				outFile.write(s.toString());
			} 
			catch (IOException e) 
			{
				e.printStackTrace();
			}
		}
	}
	
}
