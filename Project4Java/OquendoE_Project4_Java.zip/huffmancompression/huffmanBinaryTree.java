package huffmancompression;

import java.io.*;
import java.util.*;

public class huffmanBinaryTree extends Main{
	public treeNode root;
	public Scanner inFile;
	
	huffmanBinaryTree(){
		this.root = null;
	}
	
	public void constructHuffmanLList(Scanner inFile, FileWriter outFile) 
	{
		treeNode spot = new treeNode();
		treeNode listHead = new treeNode("dummy", 0);
		linkedList print_List = new linkedList();
		
		linkedList spot_To_Find = new linkedList();
		
		int Prob = 0;
		String chr = "0";
		
		while(inFile.hasNext()) 
		{
			//take in from the file
			chr = inFile.next();
			Prob = inFile.nextInt();
			treeNode newNode = new treeNode();
			newNode.chStr = chr;
			newNode.prob = Prob;
			newNode.next = null;
			
			spot = spot_To_Find.findSpot(listHead, newNode);
		
			spot_To_Find.insertOneNode(spot, newNode);
		}
		
		print_List.printList(listHead, outFile);
		//printList() from linkedList
		//print the list to outFile1 from listHead to the end of the list
		
	}
	public void constructHuffmanBinTree(treeNode listHead, FileWriter outFile) 
	{
		treeNode spot = new treeNode();
		linkedList insertNode = new linkedList();
		linkedList find_spot = new linkedList();
		linkedList print_List = new linkedList();
		
		while(listHead.next != null)
		{
			treeNode newNode = new treeNode();
			
			newNode.prob = (listHead.next.prob + listHead.next.next.prob); 
			newNode.chStr = (newNode.next.chStr + newNode.next.next.chStr);
			newNode.left = listHead.next;
			newNode.right = listHead.next.next; 
			
			spot = find_spot.findSpot(listHead, newNode);
			
			insertNode.insertOneNode(spot, newNode);
			
			listHead.next = listHead.next.next.next;
			
			print_List.printList(listHead, outFile);
			
			root = newNode;
		}
		
	}
	public void preOrderTraversal(treeNode root, FileWriter outFile) 
	{
		if(root == null) 
		{
			return;
		}
		else
		{
			treeNode print_Node = new treeNode();
			print_Node.printNode(root, outFile);
			preOrderTraversal(root.left, outFile);
			preOrderTraversal(root.right, outFile);
		}
		
	}
	public void inOrderTraversal(treeNode root, FileWriter outFile) 
	{
		if(root == null)
		{
			return;
		}
		else
		{
			inOrderTraversal(root.left, outFile);
			treeNode print_Node = new treeNode();
			print_Node.printNode(root, outFile);
			inOrderTraversal(root.right, outFile);
			
		}
	}
	public void postOrderTraversal(treeNode root, FileWriter outFile) 
	{
		if(root == null)
		{
			return;
		}
		else
		{
			postOrderTraversal(root.left, outFile);
			postOrderTraversal(root.right, outFile);
			treeNode print_Node = new treeNode();
			print_Node.printNode(root, outFile);
		}
	}
	public boolean isLeaf(treeNode leaf) 
	{
		if(leaf.right == null && leaf.left == null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
