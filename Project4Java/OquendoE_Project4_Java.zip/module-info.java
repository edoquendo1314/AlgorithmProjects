/**
 * 
 */
/**
 * @author edoqu
 *
 */
module huffmanCompression {
}