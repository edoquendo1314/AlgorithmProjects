package huffmancompression;
import java.io.*;

public class linkedList{
	//listHead -->("dummy", 0, next's chStr_1) --> (chStr_1, prob_1, next's chStr_2)...
	public treeNode listHead;

	//create constructor to handle the data
	linkedList(){
		listHead = new treeNode("dummy", 0);
		listHead.next = null; 
	}
	
	public treeNode getHead()
	{
		treeNode curr = listHead;
		return(curr); 
	}
	
	
	public int findSpot(treeNode newNode) 
	{
		treeNode curr = listHead;
		int spot = 0;
		if(curr.next == null)
		{
			spot++;
			return spot;
		}
		while(curr.next != null && newNode.prob >= curr.prob)
		{
			spot++;
			curr = curr.next; 
		}
		
		return spot; 
	}
	//linkedList use insertion sort
	public void insertionSort(int spot, treeNode newNode) 
	{
		int counter = 0;
		treeNode curr = listHead;
		
		while(curr.next != null || spot != counter)
		{
			counter++; 
			curr = curr.next; 
		}
		
		newNode.next = curr.next;
		curr.next = newNode; 
	}
	
	public void printList(FileWriter outFile) 
	{
		treeNode curr = listHead; 
		try 
		{
			while(curr.next != null)
			{	
				
					StringBuilder s = new StringBuilder();
					s.append(curr.chStr + "," + curr.prob + "," + curr.next 
							+ "\n");
					outFile.write(s.toString());
				
				curr = curr.next; 
			}
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
	}
}
