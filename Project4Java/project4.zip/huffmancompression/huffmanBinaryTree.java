package huffmancompression;

import java.io.*;
import java.util.*;

public class huffmanBinaryTree{
	public treeNode root;
	public linkedList list; 
	public Scanner inFile;
	//public String charCode[];
	//public int index = 0;
	
	huffmanBinaryTree(){
		list = new linkedList(); 
	}
	
	/*
	public void charCode(int index)
	{
		charCode = new String[index]; 
	}
	
	public void encode(Scanner inFile, FileWriter outFile)
	{
		String charIn = " ";
		String code = " ";
		int index = 0;
		
		
		while(inFile.hasNext())
		{
			charIn = inFile.next();
			index = Integer.parseInt(charIn);
			code = charCode(index);
		}
	}
	*/
	
	public void constructHuffmanLList(Scanner inFile, FileWriter outFile) 
	{
		int spot = 0;
		
		int Prob = 0;
		String chr = "0";
		
		while(inFile.hasNext()) 
		{
			//take in from the file
			chr = inFile.next();
			Prob = inFile.nextInt();
			treeNode newNode = new treeNode();
			newNode.chStr = chr;
			newNode.prob = Prob;
			newNode.next = null;
			
			spot = list.findSpot(newNode);
		
			list.insertionSort(spot, newNode);
		}
		
		list.printList(outFile);
		//printList() from linkedList
		//print the list to outFile1 from listHead to the end of the list
		
	}
	public treeNode constructHuffmanBinTree(FileWriter outFile) 
	{
		int spot = 0; 
		treeNode curr = list.getHead();
		while(curr.next != null)
		{
			treeNode newNode = new treeNode();
			
			newNode.prob = (curr.next.prob + curr.next.next.prob); 
			newNode.chStr = (newNode.next.chStr + newNode.next.next.chStr);
			newNode.left = curr.next;
			newNode.right = curr.next.next; 
			
			spot = list.findSpot(newNode);
			
			list.insertionSort(spot, newNode);
			
			curr.next = curr.next.next.next;
			
			list.printList(outFile);
			
			root = newNode;
		}
		return root; 
		
	}
	public void preOrderTraversal(treeNode root, FileWriter outFile) 
	{
		if(root == null) 
		{
			return;
		}
		else
		{
			treeNode print_Node = new treeNode();
			print_Node.printNode(root, outFile);
			preOrderTraversal(root.left, outFile);
			preOrderTraversal(root.right, outFile);
		}
		
	}
	public void inOrderTraversal(treeNode root, FileWriter outFile) 
	{
		if(root == null)
		{
			return;
		}
		else
		{
			inOrderTraversal(root.left, outFile);
			treeNode print_Node = new treeNode();
			print_Node.printNode(root, outFile);
			inOrderTraversal(root.right, outFile);
			
		}
	}
	public void postOrderTraversal(treeNode root, FileWriter outFile) 
	{
		if(root == null)
		{
			return;
		}
		else
		{
			postOrderTraversal(root.left, outFile);
			postOrderTraversal(root.right, outFile);
			treeNode print_Node = new treeNode();
			print_Node.printNode(root, outFile);
		}
	}
	public boolean isLeaf(treeNode leaf) 
	{
		if(leaf.right == null && leaf.left == null)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}
